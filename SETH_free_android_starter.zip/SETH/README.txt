SETH — FREE PERSONAL ASSISTANT STARTER

WHAT THIS IS
A simple installable Progressive Web App (PWA) prototype. It includes:
- Tasks and priorities
- Reminder records and in-app alerts while the app is open
- On-device memory notes
- Business/project notes
- Voice input where the browser supports Web Speech Recognition
- Opens the Android dialler for a number you enter
- Local browser storage

IMPORTANT LIMITATIONS
- This is not a full autonomous AI assistant yet. There is no cloud AI/API connection.
- Data is stored in this browser on this device. Clearing browser/site data may erase it.
- Reliable notifications while closed depend on browser/Android support; this starter's reminder alerts work most reliably while open.
- It cannot secretly place calls, read all your phone apps, or send WhatsApp messages.
- Power-button double-press integration is not included in a PWA. It may be possible to assign the installed app as a supported Samsung side-button app, but automatically starting microphone listening is not guaranteed.
- No software can safely access “everything” on your phone without permissions and integration limits.

HOW TO INSTALL ON SAMSUNG
A PWA must be served from HTTPS to install properly. Opening index.html directly from a file manager is for preview only.
Free hosting option:
1. On a computer or phone browser, create a GitHub account at https://github.com
2. Create a new public repository named seth-assistant.
3. Upload index.html, manifest.json, sw.js, icon-192.png, icon-512.png and README.txt to the repository root.
4. In repository Settings → Pages, choose Deploy from a branch, select main and /(root), then Save.
5. Wait for GitHub Pages to publish the HTTPS site.
6. Open the published site in Chrome on your Samsung.
7. Chrome menu (⋮) → Install app or Add to Home screen.
8. Launch SETH from its new home-screen icon. In Samsung Settings, check Advanced features → Side button for a double-press app option. Names/options vary by model.

PRIVACY
Do not save passwords, banking PINs, recovery codes, or other secrets in this prototype.
